package manojveluru.niu.edu.tictactoe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Button [][] buttons;

    private TicTacToe game;

    private TextView gameStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        //create the TicTacToe game
        game = new TicTacToe();

        buildGUI();
    }//end onCreate


    public void buildGUI()
    {
       //Get the width of the screen
        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);

        //calculate the width of 1/3 of the screen
        int width = size.x / TicTacToe.SIDE;

        //Create a gridLayout to hold the buttons for the game
        GridLayout gridLayout = new GridLayout(this);

        //set the number of rows and columns fro the grid
        //version 4 - update the number of rows to add the game status
        gridLayout.setRowCount(TicTacToe.SIDE + 1);
        gridLayout.setColumnCount(TicTacToe.SIDE);

        //Create the 2-dimensional array of buttons
        buttons = new Button[TicTacToe.SIDE][TicTacToe.SIDE];

        //handle the button clicks
        ButtonHandler buttonHandler = new ButtonHandler();
        //add the buttons to the grid layout
        for (int row=0;row<TicTacToe.SIDE;row++)
            for (int col=0;col<TicTacToe.SIDE;col++)
            {
                //generate the button to go into the 2-D array of buttons
                buttons[row][col] = new Button(this);

                //set the textsize for the information on the button
                buttons[row][col].setTextSize((int) (width*0.2));

                //add the handler to the button
                buttons[row][col].setOnClickListener(buttonHandler);
                //add the button to the gridlayout
                gridLayout.addView(buttons[row][col], width, width);
            }

         //create the TextView
        gameStatus = new TextView(this);

         //Set the size for the textView (specifications)
        GridLayout.Spec rowSpec = GridLayout.spec(TicTacToe.SIDE, 1),
                        colSpec = GridLayout.spec(0, TicTacToe.SIDE);

        GridLayout.LayoutParams layoutParamsStatus = new GridLayout.LayoutParams(rowSpec, colSpec);
        //attach the lauout parameters to the text view
        gameStatus.setLayoutParams(layoutParamsStatus);

        //create the width and height for the textView
        gameStatus.setWidth(TicTacToe.SIDE * width);
        gameStatus.setHeight(width);

        //center the textView
        gameStatus.setGravity(Gravity.CENTER);

        //set the background color
        gameStatus.setBackgroundColor(Color.MAGENTA);

        //set the text size in the text view
        gameStatus.setTextSize((int)(width*0.15));

        //put the text in the text view
        gameStatus.setText(game.result());

        //add the text view to the gridlayout
        gridLayout.addView(gameStatus);
        //display view on the screen
        setContentView(gridLayout);
    }//end buildGUI

    //The button handler
    private class ButtonHandler implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            //Display a message to indicate what has been clicked
            Toast.makeText(MainActivity.this, "ButtonHandler onClick, view is " +v, Toast.LENGTH_SHORT).show();

            //determine which button was clicked and update it
            for (int row=0;row<TicTacToe.SIDE;row++)
                for (int col=0;col<TicTacToe.SIDE;col++)
                {
                    if (v == buttons[row][col])
                    {
                        update(row,col);
                    }
                }
        }
    }//end ButtonHandler


public void update(int row, int column)
{
    //Display a message
    Toast.makeText(this, "update: "+row+", "+column, Toast.LENGTH_SHORT).show();

    //put a symbol on the button that was clicked
    //buttons[row][column].setText("X");

    //find the current player
    int currentPlayer = game.play(row, column);

    //put X or O on the board based on the player
    if (currentPlayer == 1)
    {
        buttons[row][column].setText("X");
    }
    else if(currentPlayer == 2)
    {
        buttons[row][column].setText("O");
    }

    //check if the game is done
    if (game.isGameOver())
    {
        //change the background color of the textview
        gameStatus.setBackgroundColor(Color.CYAN);

        //update the message in the textView
        gameStatus.setText(game.result());

        enableButtons(false);

        //get a dialog box to display
        showNewGameDialog();
    }
}//end update


public void enableButtons(boolean enabled)
{
    //enable or disable all of the buttons
    for (int row=0;row<TicTacToe.SIDE;row++)
        for (int col=0;col<TicTacToe.SIDE;col++)
        {
            buttons[row][col].setEnabled(enabled);
        }
}//end enableButtons

    public void showNewGameDialog()
    {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        //set the title and the message for the dialog box
        alert.setTitle("Tic Tac Toe");
        alert.setMessage("Do you want to play again?");

        //Create the positive message
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //reset the game
                game.resetGame();

                //re-enable the buttons on the game board
                enableButtons(true);

                //clear the Xs and Os from the button
                resetButtons();

                //change the textView background back to its original color
                gameStatus.setBackgroundColor(Color.MAGENTA);

                //update the text in the textView
                gameStatus.setText(game.result());
            }
        });

        //Create the negative message/button
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                //close the application
                MainActivity.this.finish();

            }
        });

        //display the dialog box
        alert.show();
    }//end showNewGameDialog

    public void resetButtons()
    {
        for(int row = 0; row<TicTacToe.SIDE;row++)
            for (int col = 0; col<TicTacToe.SIDE;col++)
                buttons[row][col].setText("");
    }//end resetButtons
}//end MainActivity
